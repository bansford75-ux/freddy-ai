FREDDY AI - VERCEL SETUP

1. Upload this folder to a GitHub repository named freddy-ai.
2. Import that repository into Vercel and Deploy.
3. In Vercel: Project -> Settings -> Environment Variables.
4. Add:
   Name: OPENAI_API_KEY
   Value: your OpenAI secret key
5. Redeploy after saving the variable.
6. Open your Vercel URL and chat with Freddy.

Never put your OpenAI key in index.html or commit it to GitHub.
